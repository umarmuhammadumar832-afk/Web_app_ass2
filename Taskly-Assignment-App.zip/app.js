/* ===== Taskly – Assignment Web App ===== */

const STORAGE_KEY = "taskly_users";
const SESSION_KEY = "taskly_session";

// ---------- Helpers ----------
function $(sel) {
  return document.querySelector(sel);
}
function $$(sel) {
  return document.querySelectorAll(sel);
}

function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

function hash(str) {
  // Simple non-crypto hash for demo (not secure for production)
  let h = 0;
  for (let i = 0; i < str.length; i++) {
    h = (Math.imul(31, h) + str.charCodeAt(i)) | 0;
  }
  return "h" + Math.abs(h).toString(16);
}

function getUsers() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY)) || {};
  } catch {
    return {};
  }
}

function saveUsers(users) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(users));
}

function getCurrentUser() {
  const email = sessionStorage.getItem(SESSION_KEY);
  if (!email) return null;
  const users = getUsers();
  return users[email] ? { email, ...users[email] } : null;
}

function setSession(email) {
  sessionStorage.setItem(SESSION_KEY, email);
}

function clearSession() {
  sessionStorage.removeItem(SESSION_KEY);
}

function formatDate(iso) {
  if (!iso) return "";
  const d = new Date(iso + "T00:00:00");
  return d.toLocaleDateString(undefined, {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}

function isOverdue(iso, status) {
  if (status === "done" || !iso) return false;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const due = new Date(iso + "T00:00:00");
  return due < today;
}

// ---------- State ----------
let currentUser = null;
let deleteTargetId = null;
let timerInterval = null;
let timerRemaining = 25 * 60; // seconds
let timerRunning = false;

// ---------- Loading ----------
function hideLoading() {
  const screen = $("#loading-screen");
  screen.classList.add("fade-out");
  setTimeout(() => {
    screen.classList.add("hidden");
  }, 450);
}

// ---------- Auth UI ----------
function showAuth(form = "login") {
  $("#auth-container").classList.remove("hidden");
  $("#app").classList.add("hidden");
  $("#login-form").classList.toggle("hidden", form !== "login");
  $("#signup-form").classList.toggle("hidden", form !== "signup");
  $("#forgot-form").classList.toggle("hidden", form !== "forgot");
  // Clear errors
  ["login-error", "signup-error", "forgot-error", "forgot-success"].forEach(
    (id) => {
      const el = $("#" + id);
      if (el) {
        el.classList.add("hidden");
        el.textContent = "";
      }
    }
  );
}

function showApp() {
  $("#auth-container").classList.add("hidden");
  $("#app").classList.remove("hidden");
  currentUser = getCurrentUser();
  if (!currentUser) {
    showAuth("login");
    return;
  }
  $("#user-greeting").textContent = `Hi, ${currentUser.name.split(" ")[0]}`;
  renderDashboard();
  updateTimerAssignmentSelect();
}

// ---------- Auth Logic ----------
function handleSignup(e) {
  e.preventDefault();
  const name = $("#signup-name").value.trim();
  const email = $("#signup-email").value.trim().toLowerCase();
  const password = $("#signup-password").value;
  const confirm = $("#signup-confirm").value;
  const err = $("#signup-error");

  if (password.length < 6) {
    err.textContent = "Password must be at least 6 characters.";
    err.classList.remove("hidden");
    return;
  }
  if (password !== confirm) {
    err.textContent = "Passwords do not match.";
    err.classList.remove("hidden");
    return;
  }

  const users = getUsers();
  if (users[email]) {
    err.textContent = "An account with this email already exists.";
    err.classList.remove("hidden");
    return;
  }

  users[email] = {
    name,
    passwordHash: hash(password),
    assignments: [],
  };
  saveUsers(users);
  setSession(email);
  showApp();
}

function handleLogin(e) {
  e.preventDefault();
  const email = $("#login-email").value.trim().toLowerCase();
  const password = $("#login-password").value;
  const err = $("#login-error");

  const users = getUsers();
  const user = users[email];
  if (!user || user.passwordHash !== hash(password)) {
    err.textContent = "Invalid email or password.";
    err.classList.remove("hidden");
    return;
  }

  setSession(email);
  showApp();
}

function handleForgot(e) {
  e.preventDefault();
  const email = $("#forgot-email").value.trim().toLowerCase();
  const password = $("#forgot-password").value;
  const confirm = $("#forgot-confirm").value;
  const err = $("#forgot-error");
  const success = $("#forgot-success");

  err.classList.add("hidden");
  success.classList.add("hidden");

  if (password.length < 6) {
    err.textContent = "Password must be at least 6 characters.";
    err.classList.remove("hidden");
    return;
  }
  if (password !== confirm) {
    err.textContent = "Passwords do not match.";
    err.classList.remove("hidden");
    return;
  }

  const users = getUsers();
  if (!users[email]) {
    err.textContent = "No account found with that email.";
    err.classList.remove("hidden");
    return;
  }

  users[email].passwordHash = hash(password);
  saveUsers(users);
  success.textContent = "Password updated! You can now log in.";
  success.classList.remove("hidden");
  $("#forgot-password").value = "";
  $("#forgot-confirm").value = "";
}

function handleLogout() {
  clearSession();
  currentUser = null;
  if (timerInterval) {
    clearInterval(timerInterval);
    timerInterval = null;
    timerRunning = false;
  }
  showAuth("login");
}

// ---------- Assignments ----------
function getAssignments() {
  const users = getUsers();
  const email = sessionStorage.getItem(SESSION_KEY);
  return (users[email] && users[email].assignments) || [];
}

function saveAssignments(list) {
  const users = getUsers();
  const email = sessionStorage.getItem(SESSION_KEY);
  if (users[email]) {
    users[email].assignments = list;
    saveUsers(users);
  }
}

function renderDashboard() {
  const assignments = getAssignments();
  const listEl = $("#assignments-list");
  const emptyEl = $("#empty-state");

  // Filters
  const statusF = $("#filter-status").value;
  const priorityF = $("#filter-priority").value;
  const subjectF = $("#filter-subject").value;
  const search = $("#search-input").value.trim().toLowerCase();

  // Populate subject filter
  const subjects = [...new Set(assignments.map((a) => a.subject).filter(Boolean))].sort();
  const subjSelect = $("#filter-subject");
  const currentSubj = subjSelect.value;
  subjSelect.innerHTML = '<option value="all">All Subjects</option>';
  subjects.forEach((s) => {
    const opt = document.createElement("option");
    opt.value = s;
    opt.textContent = s;
    subjSelect.appendChild(opt);
  });
  if (subjects.includes(currentSubj)) subjSelect.value = currentSubj;

  // Datalist for modal
  const datalist = $("#subjects-list");
  datalist.innerHTML = "";
  subjects.forEach((s) => {
    const opt = document.createElement("option");
    opt.value = s;
    datalist.appendChild(opt);
  });

  let filtered = assignments.filter((a) => {
    if (statusF !== "all" && a.status !== statusF) return false;
    if (priorityF !== "all" && a.priority !== priorityF) return false;
    if (subjectF !== "all" && a.subject !== subjectF) return false;
    if (search) {
      const hay = (a.title + " " + a.subject + " " + (a.notes || "")).toLowerCase();
      if (!hay.includes(search)) return false;
    }
    return true;
  });

  // Sort: overdue first, then by due date, then by priority
  const priorityOrder = { high: 0, medium: 1, low: 2 };
  filtered.sort((a, b) => {
    const aOver = isOverdue(a.dueDate, a.status) ? 0 : 1;
    const bOver = isOverdue(b.dueDate, b.status) ? 0 : 1;
    if (aOver !== bOver) return aOver - bOver;
    if (a.dueDate !== b.dueDate) return (a.dueDate || "").localeCompare(b.dueDate || "");
    return (priorityOrder[a.priority] ?? 2) - (priorityOrder[b.priority] ?? 2);
  });

  listEl.innerHTML = "";
  if (filtered.length === 0) {
    emptyEl.classList.remove("hidden");
  } else {
    emptyEl.classList.add("hidden");
    filtered.forEach((a) => {
      listEl.appendChild(createAssignmentCard(a));
    });
  }

  updateStats(assignments);
  updateProgress(assignments);
}

function createAssignmentCard(a) {
  const card = document.createElement("div");
  card.className = "assignment-card";
  card.dataset.id = a.id;

  const overdue = isOverdue(a.dueDate, a.status);
  const dueText = a.dueDate
    ? overdue
      ? `Overdue · ${formatDate(a.dueDate)}`
      : `Due ${formatDate(a.dueDate)}`
    : "No due date";

  card.innerHTML = `
    <div class="card-top">
      <div class="card-title">${escapeHtml(a.title)}</div>
      <div class="card-actions">
        <button class="icon-btn edit" title="Edit" data-id="${a.id}">✏️</button>
        <button class="icon-btn delete" title="Delete" data-id="${a.id}">🗑️</button>
      </div>
    </div>
    <div class="card-meta">
      <span class="badge badge-subject">${escapeHtml(a.subject || "—")}</span>
      <span class="badge badge-priority-${a.priority}">${a.priority}</span>
      <span class="badge badge-status-${a.status}">${statusLabel(a.status)}</span>
    </div>
    <div class="card-due ${overdue ? "overdue" : ""}">${dueText}</div>
    ${a.notes ? `<div class="card-notes">${escapeHtml(a.notes)}</div>` : ""}
  `;

  card.querySelector(".edit").addEventListener("click", () => openModal(a));
  card.querySelector(".delete").addEventListener("click", () => openConfirm(a.id));

  return card;
}

function statusLabel(s) {
  return { todo: "To Do", "in-progress": "In Progress", done: "Done" }[s] || s;
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

function updateStats(assignments) {
  const total = assignments.length;
  const done = assignments.filter((a) => a.status === "done").length;
  const pending = total - done;
  $("#stat-total").textContent = total;
  $("#stat-done").textContent = done;
  $("#stat-pending").textContent = pending;
}

function updateProgress(assignments) {
  const total = assignments.length;
  const done = assignments.filter((a) => a.status === "done").length;
  const pct = total === 0 ? 0 : Math.round((done / total) * 100);
  $("#progress-percent").textContent = pct + "%";
  $("#progress-fill").style.width = pct + "%";
}

// ---------- Modal ----------
function openModal(assignment = null) {
  const modal = $("#assignment-modal");
  const form = $("#assignment-form");
  form.reset();

  if (assignment) {
    $("#modal-title").textContent = "Edit Assignment";
    $("#assignment-id").value = assignment.id;
    $("#assign-title").value = assignment.title;
    $("#assign-subject").value = assignment.subject || "";
    $("#assign-due").value = assignment.dueDate || "";
    $("#assign-priority").value = assignment.priority || "medium";
    $("#assign-status").value = assignment.status || "todo";
    $("#assign-notes").value = assignment.notes || "";
  } else {
    $("#modal-title").textContent = "Add Assignment";
    $("#assignment-id").value = "";
    // Default due date: tomorrow
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    $("#assign-due").value = tomorrow.toISOString().slice(0, 10);
  }

  modal.classList.remove("hidden");
  $("#assign-title").focus();
}

function closeModal() {
  $("#assignment-modal").classList.add("hidden");
}

function handleAssignmentSubmit(e) {
  e.preventDefault();
  const id = $("#assignment-id").value;
  const title = $("#assign-title").value.trim();
  const subject = $("#assign-subject").value.trim();
  const dueDate = $("#assign-due").value;
  const priority = $("#assign-priority").value;
  const status = $("#assign-status").value;
  const notes = $("#assign-notes").value.trim();

  if (!title || !subject || !dueDate) return;

  let list = getAssignments();

  if (id) {
    const idx = list.findIndex((a) => a.id === id);
    if (idx !== -1) {
      list[idx] = { ...list[idx], title, subject, dueDate, priority, status, notes };
    }
  } else {
    list.push({
      id: uid(),
      title,
      subject,
      dueDate,
      priority,
      status,
      notes,
      createdAt: new Date().toISOString(),
    });
  }

  saveAssignments(list);
  closeModal();
  renderDashboard();
  updateTimerAssignmentSelect();
}

function openConfirm(id) {
  deleteTargetId = id;
  $("#confirm-modal").classList.remove("hidden");
}

function closeConfirm() {
  deleteTargetId = null;
  $("#confirm-modal").classList.add("hidden");
}

function confirmDelete() {
  if (!deleteTargetId) return;
  let list = getAssignments().filter((a) => a.id !== deleteTargetId);
  saveAssignments(list);
  closeConfirm();
  renderDashboard();
  updateTimerAssignmentSelect();
}

// ---------- Timer ----------
function updateTimerDisplay() {
  const m = Math.floor(timerRemaining / 60);
  const s = timerRemaining % 60;
  $("#timer-minutes").textContent = String(m).padStart(2, "0");
  $("#timer-seconds").textContent = String(s).padStart(2, "0");
}

function startTimer() {
  if (timerRunning) return;
  timerRunning = true;
  $("#timer-start").classList.add("hidden");
  $("#timer-pause").classList.remove("hidden");
  $("#timer-status-text").textContent = "Focusing… stay on task!";

  timerInterval = setInterval(() => {
    if (timerRemaining <= 0) {
      clearInterval(timerInterval);
      timerInterval = null;
      timerRunning = false;
      $("#timer-start").classList.remove("hidden");
      $("#timer-pause").classList.add("hidden");
      $("#timer-status-text").textContent = "Time’s up! Great work 🎉";
      // Optional: browser notification
      if ("Notification" in window && Notification.permission === "granted") {
        new Notification("Taskly", { body: "Focus session complete!" });
      }
      return;
    }
    timerRemaining--;
    updateTimerDisplay();
  }, 1000);
}

function pauseTimer() {
  if (!timerRunning) return;
  clearInterval(timerInterval);
  timerInterval = null;
  timerRunning = false;
  $("#timer-start").classList.remove("hidden");
  $("#timer-pause").classList.add("hidden");
  $("#timer-status-text").textContent = "Paused";
}

function resetTimer() {
  clearInterval(timerInterval);
  timerInterval = null;
  timerRunning = false;
  timerRemaining = 25 * 60;
  updateTimerDisplay();
  $("#timer-start").classList.remove("hidden");
  $("#timer-pause").classList.add("hidden");
  $("#timer-status-text").textContent = "Ready to focus";
}

function updateTimerAssignmentSelect() {
  const select = $("#timer-assignment");
  const current = select.value;
  const assignments = getAssignments().filter((a) => a.status !== "done");
  select.innerHTML = '<option value="">— None —</option>';
  assignments.forEach((a) => {
    const opt = document.createElement("option");
    opt.value = a.id;
    opt.textContent = a.title;
    select.appendChild(opt);
  });
  if ([...select.options].some((o) => o.value === current)) {
    select.value = current;
  }
}

// ---------- Navigation ----------
function switchView(view) {
  $$(".nav-item").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.view === view);
  });
  $("#view-dashboard").classList.toggle("hidden", view !== "dashboard");
  $("#view-timer").classList.toggle("hidden", view !== "timer");
  // Close mobile sidebar
  $("#sidebar").classList.remove("open");
}

// ---------- Init ----------
function init() {
  // Loading animation ~1.2s
  setTimeout(() => {
    hideLoading();
    const session = sessionStorage.getItem(SESSION_KEY);
    if (session && getUsers()[session]) {
      showApp();
    } else {
      showAuth("login");
    }
  }, 1200);

  // Auth form switches
  $("#show-signup").addEventListener("click", (e) => {
    e.preventDefault();
    showAuth("signup");
  });
  $("#show-login").addEventListener("click", (e) => {
    e.preventDefault();
    showAuth("login");
  });
  $("#show-forgot").addEventListener("click", (e) => {
    e.preventDefault();
    showAuth("forgot");
  });
  $("#back-to-login").addEventListener("click", (e) => {
    e.preventDefault();
    showAuth("login");
  });

  $("#login-form").addEventListener("submit", handleLogin);
  $("#signup-form").addEventListener("submit", handleSignup);
  $("#forgot-form").addEventListener("submit", handleForgot);
  $("#logout-btn").addEventListener("click", handleLogout);

  // Dashboard
  $("#add-assignment-btn").addEventListener("click", () => openModal());
  $("#filter-status").addEventListener("change", renderDashboard);
  $("#filter-priority").addEventListener("change", renderDashboard);
  $("#filter-subject").addEventListener("change", renderDashboard);
  $("#search-input").addEventListener("input", renderDashboard);

  // Modal
  $("#assignment-form").addEventListener("submit", handleAssignmentSubmit);
  $("#modal-close").addEventListener("click", closeModal);
  $("#modal-cancel").addEventListener("click", closeModal);
  $("#assignment-modal .modal-backdrop").addEventListener("click", closeModal);

  // Confirm delete
  $("#confirm-delete").addEventListener("click", confirmDelete);
  $("#confirm-cancel").addEventListener("click", closeConfirm);
  $("#confirm-close").addEventListener("click", closeConfirm);
  $("#confirm-modal .modal-backdrop").addEventListener("click", closeConfirm);

  // Timer
  $("#timer-start").addEventListener("click", startTimer);
  $("#timer-pause").addEventListener("click", pauseTimer);
  $("#timer-reset").addEventListener("click", resetTimer);
  updateTimerDisplay();

  // Nav
  $$(".nav-item").forEach((btn) => {
    btn.addEventListener("click", () => switchView(btn.dataset.view));
  });

  // Mobile menu
  $("#menu-toggle").addEventListener("click", () => {
    $("#sidebar").classList.toggle("open");
  });

  // Close sidebar on outside click (mobile)
  document.addEventListener("click", (e) => {
    const sidebar = $("#sidebar");
    const toggle = $("#menu-toggle");
    if (
      sidebar.classList.contains("open") &&
      !sidebar.contains(e.target) &&
      !toggle.contains(e.target)
    ) {
      sidebar.classList.remove("open");
    }
  });

  // Request notification permission for timer end
  if ("Notification" in window && Notification.permission === "default") {
    // Don't auto-request; user can allow later
  }
}

document.addEventListener("DOMContentLoaded", init);
